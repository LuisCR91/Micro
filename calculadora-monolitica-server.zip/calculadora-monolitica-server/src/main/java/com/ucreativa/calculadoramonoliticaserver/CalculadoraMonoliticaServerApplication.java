package com.ucreativa.calculadoramonoliticaserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CalculadoraMonoliticaServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(CalculadoraMonoliticaServerApplication.class, args);
	}

}
