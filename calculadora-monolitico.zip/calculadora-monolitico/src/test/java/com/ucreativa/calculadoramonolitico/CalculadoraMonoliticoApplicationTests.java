package com.ucreativa.calculadoramonolitico;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CalculadoraMonoliticoApplicationTests {

	@Test
	void contextLoads() {
	}

}
